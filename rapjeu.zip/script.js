// Base de données des featurings (qui a bossé avec qui)
// IMPORTANT : Mets les noms en MINUSCULES ici pour faciliter la vérification
const connections = {
    "nettspend": ["osamason", "lazer dim 700", "xaviersobased", "yhapojj"],
    "osamason": ["nettspend", "lazer dim 700", "boolymon", "kankan"],
    "jeune morty": ["thaumaturge", "8ruki", "j9ueve", "la fève"],
    "8ruki": ["jeune morty", "j9ueve", "thaumaturge", "bne"],
    "lazer dim 700": ["nettspend", "osamason"],
    "xaviersobased": ["nettspend", "yhapojj", "krueger"],
    "j9ueve": ["8ruki", "jeune morty", "la fève"]
};

let currentArtist = "nettspend";
let history = ["Nettspend"];
let score = 0;

const input = document.getElementById('artist-input');
const artistDisplay = document.getElementById('current-artist');
const historyDisplay = document.getElementById('history');
const feedback = document.getElementById('feedback-msg');
const countDisplay = document.getElementById('count');

input.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        checkConnection(input.value.toLowerCase().trim());
    }
});

function checkConnection(guess) {
    const validFeats = connections[currentArtist] || [];

    if (validFeats.includes(guess)) {
        // SUCCÈS
        feedback.innerText = "BIEN JOUÉ !";
        feedback.className = "success";
        
        // On met à jour le jeu
        currentArtist = guess;
        history.push(guess.charAt(0).toUpperCase() + guess.slice(1));
        score++;
        
        // Mise à jour affichage
        artistDisplay.innerText = currentArtist.toUpperCase();
        historyDisplay.innerText = history.join(" > ");
        countDisplay.innerText = score;
        input.value = "";
    } else {
        // ERREUR
        feedback.innerText = "PAS DE FEAT CONNU !";
        feedback.className = "error";
        input.value = "";
    }
}